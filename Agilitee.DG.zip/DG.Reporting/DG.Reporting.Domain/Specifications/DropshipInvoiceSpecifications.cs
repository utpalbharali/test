﻿using System.Linq.Expressions;
using DG.Reporting.Domain.Interfaces;
using DG.Reporting.Domain.Models;

namespace DG.Reporting.Domain.Specifications;

public class DropshipInvoiceSpecifications : ISpecification<DropshipInvoice>
{
    public DropshipInvoiceSpecifications(int pageNum, int pageSize, string storeId, string fiscalPeriod, string vendorName, string date, string  invoicenumber, string invoiceType, string sscStatus)
    {
       Criteria = i => 
       (string.IsNullOrEmpty(storeId) || i.LOCATION_ID == storeId) &&
       (string.IsNullOrEmpty(fiscalPeriod) || i.FISCAL_YRPD == fiscalPeriod) &&
       (string.IsNullOrEmpty(vendorName) || i.LINE_DESC == vendorName) &&
       (string.IsNullOrEmpty(date) || i.EVENT_DATE == date) &&
       (string.IsNullOrEmpty(invoicenumber) || i.INVOICE_NO == invoicenumber) &&
       (string.IsNullOrEmpty(invoiceType) || i.TRANS_TYPE == invoiceType) &&
       (string.IsNullOrEmpty(sscStatus) || i.END_DATE == sscStatus);

        PageNumber = pageNum;
        PageSize = pageSize;

        Includes = default!;
    }

    public Expression<Func<DropshipInvoice, bool>> Criteria { get; }
    public List<Expression<Func<DropshipInvoice, object>>> Includes { get; }

    public int PageSize { get; set; }

    public int PageNumber { get; set; }
}