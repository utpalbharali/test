﻿using System.Linq.Expressions;
using DG.Reporting.Domain.Interfaces;
using DG.Reporting.Domain.Models;

namespace DG.Reporting.Domain.Specifications;

public class SSCAdjustmentSpecifications : ISpecification<SSCAdjustment>
{
    public SSCAdjustmentSpecifications(string storeId, string fiscalPeriod)
    {
        Criteria = i => i.LOCATION_ID == storeId && i.FISCAL_YRPD == fiscalPeriod;
        Includes = default!;
    }

    public Expression<Func<SSCAdjustment, bool>> Criteria { get; }
    public List<Expression<Func<SSCAdjustment, object>>> Includes { get; }

    public int PageSize => throw new NotImplementedException();

    public int PageNumber => throw new NotImplementedException();
}