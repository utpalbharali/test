﻿using System.Linq.Expressions;
using DG.Reporting.Domain.Interfaces;
using DG.Reporting.Domain.Models;

namespace DG.Reporting.Domain.Specifications;

public class SBTTransactionSpecifications : ISpecification<SBTTransaction>
{
    public SBTTransactionSpecifications(string storeId, string fiscalPeriod)
    {
        Criteria = i => i.LOCATION_ID == storeId && i.FISCAL_YRPD == fiscalPeriod;
        Includes = default!;
    }

    public Expression<Func<SBTTransaction, bool>> Criteria { get; }
    public List<Expression<Func<SBTTransaction, object>>> Includes { get; }

    public int PageSize => throw new NotImplementedException();

    public int PageNumber => throw new NotImplementedException();
}