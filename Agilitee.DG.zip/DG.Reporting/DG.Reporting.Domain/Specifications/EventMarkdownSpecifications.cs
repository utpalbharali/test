﻿using System.Linq.Expressions;
using DG.Reporting.Domain.Interfaces;
using DG.Reporting.Domain.Models;

namespace DG.Reporting.Domain.Specifications;

public class EventMarkdownSpecifications : ISpecification<EventMarkdown>
{
    public EventMarkdownSpecifications(int pageNum, int pageSize, string storeId, string fiscalPeriod, string transType, string endDate, string retailValue)
    {
        Criteria = i => 
       (string.IsNullOrEmpty(storeId) || i.LOCATION_ID == storeId) &&
       (string.IsNullOrEmpty(fiscalPeriod) || i.FISCAL_YRPD == fiscalPeriod) &&
       (string.IsNullOrEmpty(transType) || i.TRANS_TYPE == transType) &&
       (string.IsNullOrEmpty(endDate) || i.END_DATE == endDate) &&
       (string.IsNullOrEmpty(retailValue) || i.EXT_RETAIL_AMT == retailValue);

        PageNumber = pageNum;
        PageSize = pageSize;

        Includes = default!;
    }

    public Expression<Func<EventMarkdown, bool>> Criteria { get; }
    public List<Expression<Func<EventMarkdown, object>>> Includes { get; }

    public int PageSize { get; set; }

    public int PageNumber { get; set; }
}