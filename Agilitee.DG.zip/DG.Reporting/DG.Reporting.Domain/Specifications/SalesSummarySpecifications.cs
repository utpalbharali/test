﻿using System.Linq.Expressions;
using DG.Reporting.Domain.Interfaces;
using DG.Reporting.Domain.Models;

namespace DG.Reporting.Domain.Specifications;

public class SalesSummarySpecifications : ISpecification<SalesSummary>
{
	//public SalesSummarySpecifications(string storeId, string fiscalPeriod)
	//{
	//    Criteria = i => i.LOCATION_ID == storeId && i.FISCAL_YRPD == fiscalPeriod;
	//    Includes = default!;
	//}

	//public Expression<Func<SalesSummary, bool>> Criteria { get; }
	//public List<Expression<Func<SalesSummary, object>>> Includes { get; }

	//public int PageSize => throw new NotImplementedException();

	//public int PageNumber => throw new NotImplementedException();


	public int PageSize { get; private set; }
	public int PageNumber { get; private set; }

	public Expression<Func<SalesSummary, bool>> Criteria { get; private set; }
	public List<Expression<Func<SalesSummary, object>>> Includes { get; private set; }

	public SalesSummarySpecifications(
		Expression<Func<SalesSummary, bool>> criteria,
		List<Expression<Func<SalesSummary, object>>> includes,
		int pageSize = 10,
		int pageNumber = 1)
	{
		Criteria = criteria ?? throw new ArgumentNullException(nameof(criteria));
		Includes = includes ?? new List<Expression<Func<SalesSummary, object>>>();
		PageSize = pageSize;
		PageNumber = pageNumber;
	}
}