﻿using System.Linq.Expressions;

namespace DG.Reporting.Domain.Interfaces;

public interface ISpecification<T>
{

    int PageSize { get; }
    int PageNumber { get; }

    Expression<Func<T, bool>> Criteria { get; }
    List<Expression<Func<T, object>>> Includes { get; }
}
