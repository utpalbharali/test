﻿namespace DG.Reporting.Domain.Interfaces;

public interface IEntity<T>
{
    T ID { get; set; }
}
