using DG.Reporting.Domain.Interfaces;

namespace DG.Reporting.Domain.Models;

public class EventMarkdown : IEntity<string>
{
    public string ID { get; set; } = default!;
    public string FISCAL_YRPD { get; set; } = default!;
    public string LOCATION_ID { get; set; } = default!;
    public string SECTION_DESC { get; set; } = default!;
    public string EVENT_DATE { get; set; } = default!;
    public string LINE_DESC { get; set; } = default!;
    public string EXT_RETAIL_AMT { get; set; } = default!;
    public string TRANS_TYPE { get; set; } = default!;
    public string BATCH_ID { get; set; } = default!;
    public string INVOICE_NO { get; set; } = default!;
    public string TRAILER_NO { get; set; } = default!;
    public string DOC_NO { get; set; } = default!;
    public string BEGIN_DATE { get; set; } = default!;
    public string END_DATE { get; set; } = default!;
    public string SENDING_LOCATION { get; set; } = default!;
    public string RECEIVING_LOCATION { get; set; } = default!;
    public string FISCAL_WK { get; set; } = default!;
    public string BEG_INVENTORY_BAL { get; set; } = default!;
    public string END_INVENTORY_BAL { get; set; } = default!;
    public string TOTAL_CREDITS { get; set; } = default!;
    public string TOTAL_DEBITS { get; set; } = default!;
    public string ACKCDDT { get; set; } = default!;
    public string SSC_STATUS { get; set; } = default!;
}