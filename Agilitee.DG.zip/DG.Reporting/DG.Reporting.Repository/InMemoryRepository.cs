﻿using DG.Reporting.Domain.Interfaces;
using DG.Reporting.Domain.Models;
using static System.Net.Mime.MediaTypeNames;
using System.Reflection;
using System.Linq;

namespace DG.Reporting.Repository;

public class InMemoryRepository<T> : IRepository<T> where T : class, IEntity<string>
{
    private readonly List<T> _entities;

    public InMemoryRepository()
    {
        string jsonFile = System.IO.Path.Combine(System.IO.Directory.GetCurrentDirectory(), "Data", "Json", typeof(T).Name.ToString() + ".json");
        string fileContents = File.ReadAllText(jsonFile);

        _entities = Newtonsoft.Json.JsonConvert.DeserializeObject<List<T>>(fileContents).ToList();
    }

    public async Task AddAsync(T entity)
    {
        _entities.Add(entity);
        await Task.CompletedTask;
    }

    public async Task DeleteAsync(string id)
    {
        var entity = await GetByIdAsync(id);
        if (entity != null)
        {
            _entities.Remove(entity);
        }
        await Task.CompletedTask;
    }

    public async Task<IEnumerable<T>> GetAllAsync()
    {
        return await Task.FromResult(_entities.AsEnumerable());
    }

    public async Task<T?> GetByIdAsync(string id)
    {
        return await Task.FromResult(_entities?.FirstOrDefault(e => e.ID == id));
    }

    public async Task UpdateAsync(T entity) => await Task.CompletedTask;

    public async Task<IEnumerable<T>> SearchAsync(ISpecification<T> specification)
    {
        var query = _entities.AsQueryable();

        if (specification.Criteria != null)
        {
            query = query.Where(specification.Criteria);
            if (specification.PageNumber > 0)
            {
                query = query.Skip(specification.PageNumber);
            }

            if (specification.PageSize > 0)
            {
                query = query.Take(specification.PageSize);
            }
        }

        return await Task.FromResult(query.AsEnumerable());
    }

}
