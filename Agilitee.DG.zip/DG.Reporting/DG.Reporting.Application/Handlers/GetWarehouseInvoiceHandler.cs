﻿using AutoMapper;
using MediatR;
using DG.Reporting.Domain.Interfaces;
using DG.Reporting.Domain.Models;
using DG.Reporting.Application.Queries;

namespace DG.Reporting.Application.Handlers;

public class GetWarehouseInvoiceHandler : IRequestHandler<GetWarehouseInvoiceQuery, IEnumerable<WarehouseInvoice>>
{
    private readonly IRepository<WarehouseInvoice> repository;
    private readonly IMapper mapper;

    public GetWarehouseInvoiceHandler(IRepository<WarehouseInvoice> repository, IMapper mapper)
    {
        this.repository = repository;
        this.mapper = mapper;
    }

    public async Task<IEnumerable<WarehouseInvoice>> Handle(GetWarehouseInvoiceQuery request, CancellationToken cancellationToken)
    {
        var results = await repository.GetAllAsync();
        return mapper.Map<IEnumerable<WarehouseInvoice>>(results);
    }
}
