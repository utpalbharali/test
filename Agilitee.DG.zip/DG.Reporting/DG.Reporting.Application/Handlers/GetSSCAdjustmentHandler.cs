﻿using AutoMapper;
using MediatR;
using DG.Reporting.Domain.Interfaces;
using DG.Reporting.Domain.Models;
using DG.Reporting.Application.Queries;

namespace DG.Reporting.Application.Handlers;

public class GetSSCAdjustmentHandler : IRequestHandler<GetSSCAdjustmentQuery, IEnumerable<SSCAdjustment>>
{
    private readonly IRepository<SSCAdjustment> repository;
    private readonly IMapper mapper;

    public GetSSCAdjustmentHandler(IRepository<SSCAdjustment> repository, IMapper mapper)
    {
        this.repository = repository;
        this.mapper = mapper;
    }

    public async Task<IEnumerable<SSCAdjustment>> Handle(GetSSCAdjustmentQuery request, CancellationToken cancellationToken)
    {
        var results = await repository.GetAllAsync();
        return mapper.Map<IEnumerable<SSCAdjustment>>(results);
    }
}
