﻿using AutoMapper;
using MediatR;
using DG.Reporting.Domain.Interfaces;
using DG.Reporting.Domain.Models;
using DG.Reporting.Application.Queries;

namespace DG.Reporting.Application.Handlers;

public class GetEventMarkdownHandler : IRequestHandler<GetEventMarkdownQuery, IEnumerable<EventMarkdown>>
{
    private readonly IRepository<EventMarkdown> repository;
    private readonly IMapper mapper;

    public GetEventMarkdownHandler(IRepository<EventMarkdown> repository, IMapper mapper)
    {
        this.repository = repository;
        this.mapper = mapper;
    }

    public async Task<IEnumerable<EventMarkdown>> Handle(GetEventMarkdownQuery request, CancellationToken cancellationToken)
    {
        var results = await repository.GetAllAsync();
        return mapper.Map<IEnumerable<EventMarkdown>>(results);
    }
}
