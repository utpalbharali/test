﻿using AutoMapper;
using DG.Reporting.Application.Queries;
using DG.Reporting.Domain.Interfaces;
using DG.Reporting.Domain.Models;
using DG.Reporting.Domain.Specifications;
using MediatR;

namespace DG.Reporting.Application.Handlers.Search
{
    internal class SearchSalesSummaryHandler : IRequestHandler<SearchSalesSummaryQuery, IEnumerable<SalesSummary>>
    {
        private readonly IRepository<SalesSummary> _repository;
        private readonly IMapper _mapper;

        public SearchSalesSummaryHandler(IRepository<SalesSummary> repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }
        public async Task<IEnumerable<SalesSummary>> Handle(SearchSalesSummaryQuery request, CancellationToken cancellationToken)
        {
            var specification = new SalesSummarySpecifications(request.FiscalPeriod, request.StoreNumber);
            var searchResults = await _repository.SearchAsync(specification);
            return _mapper.Map<IEnumerable<SalesSummary>>(searchResults);
        }
    }
}
