﻿using AutoMapper;
using DG.Reporting.Application.Queries;
using DG.Reporting.Domain.Interfaces;
using DG.Reporting.Domain.Models;
using DG.Reporting.Domain.Specifications;
using MediatR;

namespace DG.Reporting.Application.Handlers.Search
{
    internal class SearchSBTTrasnasctionHandler : IRequestHandler<SearchSBTTrasnasctionQuery, IEnumerable<SBTTransaction>>
    {
        private readonly IRepository<SBTTransaction> _repository;
        private readonly IMapper _mapper;

        public SearchSBTTrasnasctionHandler(IRepository<SBTTransaction> repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }
        public async Task<IEnumerable<SBTTransaction>> Handle(SearchSBTTrasnasctionQuery request, CancellationToken cancellationToken)
        {
            var specification = new SBTTransactionSpecifications(request.FiscalPeriod, request.StoreNumber);
            var searResults = await _repository.SearchAsync(specification);
            return _mapper.Map<IEnumerable<SBTTransaction>>(searResults);
        }
    }
}
