﻿using AutoMapper;
using DG.Reporting.Application.Queries;
using DG.Reporting.Domain.Interfaces;
using DG.Reporting.Domain.Models;
using DG.Reporting.Domain.Specifications;
using MediatR;

namespace DG.Reporting.Application.Handlers.Search
{
    internal class SearchDropshipInvoiceHandler : IRequestHandler<SearchDropshipInvoiceQuery, IEnumerable<DropshipInvoice>>
    {
        private readonly IRepository<DropshipInvoice> _repository;
        private readonly IMapper _mapper;

        public SearchDropshipInvoiceHandler(IRepository<DropshipInvoice> repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }
        public async Task<IEnumerable<DropshipInvoice>> Handle(SearchDropshipInvoiceQuery request, CancellationToken cancellationToken)
        {
            var specification = new DropshipInvoiceSpecifications(request.PageNum, request.PageSize, request.StoreNumber, request.FiscalPeriod, request.VendorName, request.InvoiceDate, request.InvoiceNumber, request.InvoiceType, request.SSCStatus);
            var searResults = await _repository.SearchAsync(specification);
            return _mapper.Map<IEnumerable<DropshipInvoice>>(searResults);
        }
    }
}
