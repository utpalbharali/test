﻿using AutoMapper;
using DG.Reporting.Application.Queries;
using DG.Reporting.Domain.Interfaces;
using DG.Reporting.Domain.Models;
using DG.Reporting.Domain.Specifications;
using MediatR;

namespace DG.Reporting.Application.Handlers.Search
{
    internal class SearchSSCAdjustmentHandler : IRequestHandler<GetSSCAdjustmentQuery, IEnumerable<SSCAdjustment>>
    {
        private readonly IRepository<SSCAdjustment> _repository;
        private readonly IMapper _mapper;

        public SearchSSCAdjustmentHandler(IRepository<SSCAdjustment> repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }
        public async Task<IEnumerable<SSCAdjustment>> Handle(GetSSCAdjustmentQuery request, CancellationToken cancellationToken)
        {
            //var specification = new SSCAdjustmentSpecifications(request., request.StoreNumber);
            //var searResults = await _repository.SearchAsync(specification);
            //return _mapper.Map<IEnumerable<SSCAdjustment>>(searResults);
            return null;
        }
    }
}
