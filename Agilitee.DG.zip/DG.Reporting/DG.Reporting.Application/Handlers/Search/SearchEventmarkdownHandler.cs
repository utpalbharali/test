﻿using AutoMapper;
using DG.Reporting.Application.Queries;
using DG.Reporting.Domain.Interfaces;
using DG.Reporting.Domain.Models;
using DG.Reporting.Domain.Specifications;
using MediatR;

namespace DG.Reporting.Application.Handlers.Search
{
    internal class SearchEventmarkdownHandler : IRequestHandler<SearchEventMarkdownQuery, IEnumerable<EventMarkdown>>
    {
        private readonly IRepository<EventMarkdown> _repository;
        private readonly IMapper _mapper;

        public SearchEventmarkdownHandler(IRepository<EventMarkdown> repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }
        public async Task<IEnumerable<EventMarkdown>> Handle(SearchEventMarkdownQuery request, CancellationToken cancellationToken)
        {
            var specification = new EventMarkdownSpecifications(request.PageNum, request.PageSize , request.FiscalPeriod, request.StoreNumber, request.TransactionType, request.EndDate, request.Retailvalue);
            var searResults = await _repository.SearchAsync(specification);
            return _mapper.Map<IEnumerable<EventMarkdown>>(searResults);
        }

    }
}
