﻿using AutoMapper;
using DG.Reporting.Application.Queries;
using DG.Reporting.Domain.Interfaces;
using DG.Reporting.Domain.Models;
using DG.Reporting.Domain.Specifications;
using MediatR;

namespace DG.Reporting.Application.Handlers.Search
{
    internal class SearchHHTAdjustmentHandler : IRequestHandler<SearchHHTAdjustmentQuery, IEnumerable<HHTAdjustment>>
    {
        private readonly IRepository<HHTAdjustment> _repository;
        private readonly IMapper _mapper;

        public SearchHHTAdjustmentHandler(IRepository<HHTAdjustment> repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }
        public async Task<IEnumerable<HHTAdjustment>> Handle(SearchHHTAdjustmentQuery request, CancellationToken cancellationToken)
        {
            var specification = new HHTAdjustmentSpecifications(request.FiscalPeriod, request.StoreNumber);
            var searResults = await _repository.SearchAsync(specification);
            return _mapper.Map<IEnumerable<HHTAdjustment>>(searResults);
        }
    }
}
