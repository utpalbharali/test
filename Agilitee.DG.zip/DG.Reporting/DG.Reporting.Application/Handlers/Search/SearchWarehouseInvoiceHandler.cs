﻿using AutoMapper;
using DG.Reporting.Application.Queries;
using DG.Reporting.Domain.Interfaces;
using DG.Reporting.Domain.Models;
using DG.Reporting.Domain.Specifications;
using MediatR;

namespace DG.Reporting.Application.Handlers.Search
{
    internal class SearchWarehouseInvoiceHandler : IRequestHandler<SearchWarehouseInvoiceQuery, IEnumerable<WarehouseInvoice>>
    {
        private readonly IRepository<WarehouseInvoice> _repository;
        private readonly IMapper _mapper;

        public SearchWarehouseInvoiceHandler(IRepository<WarehouseInvoice> repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }
        public async Task<IEnumerable<WarehouseInvoice>> Handle(SearchWarehouseInvoiceQuery request, CancellationToken cancellationToken)
        {
            var specification = new WarehouseInvoiceSpecifications(request.FiscalPeriod, request.StoreNumber);
            var searResults = await _repository.SearchAsync(specification);
            return _mapper.Map<IEnumerable<WarehouseInvoice>>(searResults);
        }
    }
}
