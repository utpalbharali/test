﻿using AutoMapper;
using MediatR;
using DG.Reporting.Domain.Interfaces;
using DG.Reporting.Domain.Models;
using DG.Reporting.Application.Queries;

namespace DG.Reporting.Application.Handlers;

public class GetDropshipInvoiceHandler : IRequestHandler<GetDropshipInvoiceQuery, IEnumerable<DropshipInvoice>>
{
    private readonly IRepository<DropshipInvoice> repository;
    private readonly IMapper mapper;

    public GetDropshipInvoiceHandler(IRepository<DropshipInvoice> repository, IMapper mapper)
    {
        this.repository = repository;
        this.mapper = mapper;
    }

    public async Task<IEnumerable<DropshipInvoice>> Handle(GetDropshipInvoiceQuery request, CancellationToken cancellationToken)
    {
        var results = await repository.GetAllAsync();
        return mapper.Map<IEnumerable<DropshipInvoice>>(results);
    }
}
