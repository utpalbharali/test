﻿using AutoMapper;
using MediatR;
using DG.Reporting.Domain.Interfaces;
using DG.Reporting.Domain.Models;
using DG.Reporting.Application.Queries;

namespace DG.Reporting.Application.Handlers;

public class GetHHTAdjustmentHandler : IRequestHandler<GetHHTAdjustmentQuery, IEnumerable<HHTAdjustment>>
{
    private readonly IRepository<HHTAdjustment> repository;
    private readonly IMapper mapper;

    public GetHHTAdjustmentHandler(IRepository<HHTAdjustment> repository, IMapper mapper)
    {
        this.repository = repository;
        this.mapper = mapper;
    }

    public async Task<IEnumerable<HHTAdjustment>> Handle(GetHHTAdjustmentQuery request, CancellationToken cancellationToken)
    {
        var results = await repository.GetAllAsync();
        return mapper.Map<IEnumerable<HHTAdjustment>>(results);
    }
}
