﻿using AutoMapper;
using MediatR;
using DG.Reporting.Domain.Interfaces;
using DG.Reporting.Domain.Models;
using DG.Reporting.Application.Queries;
using DG.Reporting.Domain.Specifications;

namespace DG.Reporting.Application.Handlers;

public class GetSalesSummaryHandler : IRequestHandler<GetSalesSummaryQuery, IEnumerable<SalesSummary>>
{
    private readonly IRepository<SalesSummary> repository;
    private readonly IMapper mapper;

    public GetSalesSummaryHandler(IRepository<SalesSummary> repository, IMapper mapper)
    {
        this.repository = repository;
        this.mapper = mapper;
    }

    public async Task<IEnumerable<SalesSummary>> Handle(GetSalesSummaryQuery request, CancellationToken cancellationToken)
    {
        var results = await repository.GetAllAsync();
        return mapper.Map<IEnumerable<SalesSummary>>(results);
    }
}
