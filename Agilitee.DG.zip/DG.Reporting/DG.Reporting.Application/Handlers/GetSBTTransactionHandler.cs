﻿using AutoMapper;
using MediatR;
using DG.Reporting.Domain.Interfaces;
using DG.Reporting.Domain.Models;
using DG.Reporting.Application.Queries;

namespace DG.Reporting.Application.Handlers;

public class GetSBTTransactionHandler : IRequestHandler<GetSBTTransactionQuery, IEnumerable<SBTTransaction>>
{
    private readonly IRepository<SBTTransaction> repository;
    private readonly IMapper mapper;

    public GetSBTTransactionHandler(IRepository<SBTTransaction> repository, IMapper mapper)
    {
        this.repository = repository;
        this.mapper = mapper;
    }

    public async Task<IEnumerable<SBTTransaction>> Handle(GetSBTTransactionQuery request, CancellationToken cancellationToken)
    {
        var results = await repository.GetAllAsync();
        return mapper.Map<IEnumerable<SBTTransaction>>(results);
    }
}
