﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace DG.Reporting.Application
{
    public class ApplicationAssembly
    {
        public static Assembly GetAssembly() { return typeof(ApplicationAssembly).Assembly; }
    }
}
