﻿using MediatR;
using DG.Reporting.Domain.Models;

namespace DG.Reporting.Application.Queries;

public record GetEventMarkdownQuery(int PageNumber, int PageSize, String fiscalPeriod, string storeNo, string transType, string endDate, string retailsValue) : IRequest<IEnumerable<EventMarkdown>>;
