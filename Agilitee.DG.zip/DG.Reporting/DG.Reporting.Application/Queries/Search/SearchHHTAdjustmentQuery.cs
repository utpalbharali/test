﻿using DG.Reporting.Application.DTO;
using DG.Reporting.Domain.Models;
using MediatR;

namespace DG.Reporting.Application.Queries;

public class SearchHHTAdjustmentQuery : HHTAdjustmentDTO, IRequest<IEnumerable<HHTAdjustment>>
{

    public SearchHHTAdjustmentQuery(string fiscalPeriod, string storeNumber, string docNumber, string date)
    {
        FiscalPeriod = fiscalPeriod;
        StoreNumber = storeNumber;
        DocumentNumber = docNumber;
        Date = date;
    }
}