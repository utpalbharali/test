﻿using DG.Reporting.Application.DTO;
using DG.Reporting.Domain.Models;
using MediatR;

namespace DG.Reporting.Application.Queries;

public class SearchEventMarkdownQuery : EventMarkdownDTO, IRequest<IEnumerable<EventMarkdown>>
{

    public SearchEventMarkdownQuery(int pageNumber, int pageSize, String fiscalPeriod, string storeNo, string transType, string endDate, string retailsValue)
    {
        PageNum = pageNumber;
        PageSize = pageSize;
        FiscalPeriod = fiscalPeriod;
        StoreNumber = storeNo;
        TransactionType = transType;
        EndDate = endDate;
        Retailvalue = retailsValue;

    }
}