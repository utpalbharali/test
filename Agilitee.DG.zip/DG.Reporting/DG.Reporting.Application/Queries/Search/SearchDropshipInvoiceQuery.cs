﻿using DG.Reporting.Application.DTO;
using DG.Reporting.Domain.Models;
using MediatR;

namespace DG.Reporting.Application.Queries;

public class SearchDropshipInvoiceQuery : DropshipInvoiceDTO, IRequest<IEnumerable<DropshipInvoice>>
{

    public SearchDropshipInvoiceQuery(int pageNumber, int pageSize, string storeNo, String fiscalPeriod, string vendorName, string date, string invoiceNumber, string invoiceType, string sscStatus)
    {
        PageNum = pageNumber;
        PageSize = pageSize;
        StoreNumber = storeNo;
        FiscalPeriod = fiscalPeriod;
        VendorName = vendorName;
        InvoiceDate = date;
        InvoiceNumber = invoiceNumber;
        InvoiceType = invoiceType;
        SSCStatus = sscStatus;
    }
}