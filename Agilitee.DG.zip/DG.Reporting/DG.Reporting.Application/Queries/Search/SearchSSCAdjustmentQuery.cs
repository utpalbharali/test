﻿using DG.Reporting.Application.DTO;
using DG.Reporting.Domain.Models;
using MediatR;

namespace DG.Reporting.Application.Queries;

public class SearchSSCAdjustmentQuery : SSCAdjustmentDTO, IRequest<IEnumerable<SSCAdjustment>>
{

    public SearchSSCAdjustmentQuery(string fiscalPeriod, string storeNumber, string date, string transType)
    {
        FiscalPeriod = fiscalPeriod;
        StoreNumber = storeNumber;
        Date = date;
        TransactionType = transType;
    }
}