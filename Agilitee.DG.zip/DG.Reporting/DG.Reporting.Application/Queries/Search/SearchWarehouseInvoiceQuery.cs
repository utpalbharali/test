﻿using DG.Reporting.Application.DTO;
using DG.Reporting.Domain.Models;
using MediatR;

namespace DG.Reporting.Application.Queries;

public class SearchWarehouseInvoiceQuery : WarehouseInvoiceDTO, IRequest<IEnumerable<WarehouseInvoice>>
{

    public SearchWarehouseInvoiceQuery(string fiscalPeriod, string storeNumber, string trailerNumber, string date, string invoiceNumber, string batchId, string acknowledgementType)
    {
        FiscalPeriod = fiscalPeriod;
        StoreNumber = storeNumber;
        TrailerNumber = trailerNumber;
        InvoiceDate = date;
        InvoiceNumber = invoiceNumber;
        BatchId = batchId;
        AcknowledgementType = acknowledgementType;
    }
}