﻿using DG.Reporting.Application.DTO;
using DG.Reporting.Domain.Models;
using MediatR;

namespace DG.Reporting.Application.Queries;

public class SearchSBTTrasnasctionQuery : SBTTransactionDTO, IRequest<IEnumerable<SBTTransaction>>
{

    public SearchSBTTrasnasctionQuery(string fiscalPeriod, string storeNumber, string startdate, string endDate, string transType)
    {
        FiscalPeriod = fiscalPeriod;
        StoreNumber = storeNumber;
        StartDate = startdate;
        EndDate = endDate;
        TransactionType = transType;
    }
}