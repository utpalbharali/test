﻿using MediatR;
using DG.Reporting.Domain.Models;

namespace DG.Reporting.Application.Queries;

public record GetWarehouseInvoiceQuery(int PageNumber, int PageSize) : IRequest<IEnumerable<WarehouseInvoice>>;
