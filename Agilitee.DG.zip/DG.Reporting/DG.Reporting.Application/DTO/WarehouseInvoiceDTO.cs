﻿namespace DG.Reporting.Application.DTO;

public class WarehouseInvoiceDTO
{
    public string FiscalPeriod { get; set; }
    public string StoreNumber { get; set; }
    public string TrailerNumber { get; set; }
    public string InvoiceDate { get; set; }
    public string InvoiceNumber { get; set; }
    public string BatchId { get; set; }
    public string AcknowledgementType { get; set; }
    public string Retailvalue { get; set; }
}
