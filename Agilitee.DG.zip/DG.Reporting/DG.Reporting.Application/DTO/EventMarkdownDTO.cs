﻿namespace DG.Reporting.Application.DTO;

public class EventMarkdownDTO : BaseDTO
{
    public string TransactionType { get; set; }
    public string EndDate { get; set; }
    public string Retailvalue { get; set; }
}
