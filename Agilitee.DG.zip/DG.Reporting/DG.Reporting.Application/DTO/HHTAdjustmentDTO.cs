﻿namespace DG.Reporting.Application.DTO;

public class HHTAdjustmentDTO
{
    public string FiscalPeriod { get; set; }
    public string StoreNumber { get; set; }
    public string DocumentNumber { get; set; }
    public string Date { get; set; }
    public string Description { get; set; }
    public string Retailvalue { get; set; }
}
