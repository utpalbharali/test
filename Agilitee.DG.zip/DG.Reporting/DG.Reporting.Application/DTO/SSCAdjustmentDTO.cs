﻿namespace DG.Reporting.Application.DTO;

public class SSCAdjustmentDTO
{
    public string FiscalPeriod { get; set; }
    public string StoreNumber { get; set; }
    public string Date { get; set; }
    public string Description { get; set; }
    public string TransactionType { get; set; }
    public string Retailvalue { get; set; }
}
