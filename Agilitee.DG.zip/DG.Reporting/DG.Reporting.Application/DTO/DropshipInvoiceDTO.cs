﻿namespace DG.Reporting.Application.DTO;

public class DropshipInvoiceDTO : BaseDTO
{
    public string VendorName { get; set; }
    public string InvoiceDate { get; set; }
    public string InvoiceNumber { get; set; }
    public string InvoiceType { get; set; }
    public string SSCStatus { get; set; }
    public string Retailvalue { get; set; }
}
