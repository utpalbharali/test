﻿namespace DG.Reporting.Application.DTO;

public class SalesSummaryDTO
{
    public string FiscalPeriod { get; set; }
    public string StoreNumber { get; set; }
    public string StartDate { get; set; }
    public string EndDate { get; set; }
    public string TransactionType { get; set; }
    public string Description { get; set; }
    public string Retailvalue { get; set; }
}
