﻿using AutoMapper;
using DG.Reporting.Application.DTO;
using DG.Reporting.Domain.Models;

namespace DG.Application.Mappings;

public class SalesSummaryProfile : Profile
{
    public SalesSummaryProfile()
    {
        CreateMap<SalesSummary, SalesSummaryDTO>()
                .ForMember(dest => dest.FiscalPeriod, opt => opt.MapFrom(src => src.FISCAL_YRPD.ToString()))
                .ForMember(dest => dest.StoreNumber, opt => opt.MapFrom(src => src.LOCATION_ID.ToString()))
                .ForMember(dest => dest.StartDate, opt => opt.MapFrom(src => src.BEGIN_DATE.ToString()))
                .ForMember(dest => dest.EndDate, opt => opt.MapFrom(src => src.END_DATE.ToString()))
                .ForMember(dest => dest.Description, opt => opt.MapFrom(src => src.LINE_DESC.ToString()))
                .ForMember(dest => dest.TransactionType, opt => opt.MapFrom(src => src.TRANS_TYPE.ToString()))
                .ForMember(dest => dest.Retailvalue, opt => opt.MapFrom(src => src.EXT_RETAIL_AMT.ToString()));
    }
}
