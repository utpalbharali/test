﻿using AutoMapper;
using DG.Reporting.Application.DTO;
using DG.Reporting.Domain.Models;

namespace DG.Application.Mappings;

public class DropshipInvoiceProfile : Profile
{
    public DropshipInvoiceProfile()
    {
        CreateMap<DropshipInvoice, DropshipInvoiceDTO>()
                .ForMember(dest => dest.FiscalPeriod, opt => opt.MapFrom(src => src.FISCAL_YRPD.ToString()))
                .ForMember(dest => dest.StoreNumber, opt => opt.MapFrom(src => src.LOCATION_ID.ToString()))
                .ForMember(dest => dest.VendorName, opt => opt.MapFrom(src => src.LINE_DESC.ToString()))
                .ForMember(dest => dest.InvoiceDate, opt => opt.MapFrom(src => src.EVENT_DATE.ToString()))
                .ForMember(dest => dest.InvoiceNumber, opt => opt.MapFrom(src => src.INVOICE_NO.ToString()))
                .ForMember(dest => dest.InvoiceType, opt => opt.MapFrom(src => src.TRANS_TYPE.ToString()))
                .ForMember(dest => dest.Retailvalue, opt => opt.MapFrom(src => src.EXT_RETAIL_AMT.ToString()));
    }
}
