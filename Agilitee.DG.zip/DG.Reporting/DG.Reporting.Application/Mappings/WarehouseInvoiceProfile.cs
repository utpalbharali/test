﻿using AutoMapper;
using DG.Reporting.Application.DTO;
using DG.Reporting.Domain.Models;

namespace DG.Application.Mappings;

public class WarehouseInvoiceProfile : Profile
{
    public WarehouseInvoiceProfile()
    {
        CreateMap<WarehouseInvoice, WarehouseInvoiceDTO>()
                .ForMember(dest => dest.FiscalPeriod, opt => opt.MapFrom(src => src.FISCAL_YRPD.ToString()))
                .ForMember(dest => dest.StoreNumber, opt => opt.MapFrom(src => src.LOCATION_ID.ToString()))
                .ForMember(dest => dest.TrailerNumber, opt => opt.MapFrom(src => src.TRAILER_NO.ToString()))
                .ForMember(dest => dest.InvoiceDate, opt => opt.MapFrom(src => src.EVENT_DATE.ToString()))
                .ForMember(dest => dest.InvoiceNumber, opt => opt.MapFrom(src => src.INVOICE_NO.ToString()))
                .ForMember(dest => dest.BatchId, opt => opt.MapFrom(src => src.BATCH_ID.ToString()))
                .ForMember(dest => dest.Retailvalue, opt => opt.MapFrom(src => src.EXT_RETAIL_AMT.ToString()));
    }
}
