using DG.Reporting.Api.Services;
using DG.Reporting.Application;
using DG.Reporting.Application.DTO;
using DG.Reporting.Domain.Interfaces;
using DG.Reporting.Domain.Models;
using DG.Reporting.Repository;
using System.Reflection;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddGrpcReflection();
builder.Services.AddGrpc();

builder.Services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(Program).GetTypeInfo().Assembly));
builder.Services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(ApplicationAssembly.GetAssembly()));

builder.Services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());

builder.Services.AddScoped<IRepository<SalesSummary>, InMemoryRepository<SalesSummary>>();
builder.Services.AddScoped<IRepository<DropshipInvoice>, InMemoryRepository<DropshipInvoice>>();
builder.Services.AddScoped<IRepository<HHTAdjustment>, InMemoryRepository<HHTAdjustment>>();
builder.Services.AddScoped<IRepository<SBTTransaction>, InMemoryRepository<SBTTransaction>>();
builder.Services.AddScoped<IRepository<SSCAdjustment>, InMemoryRepository<SSCAdjustment>>();
builder.Services.AddScoped<IRepository<WarehouseInvoice>, InMemoryRepository<WarehouseInvoice>>();
builder.Services.AddScoped<IRepository<EventMarkdown>, InMemoryRepository<EventMarkdown>>();

var app = builder.Build();

// Configure the HTTP request pipeline.
app.MapGrpcService<ReportService>();
app.MapGrpcReflectionService();
app.MapGet("/", () => "Communication with gRPC endpoints must be made through a gRPC client. To learn how to create a client, visit: https://go.microsoft.com/fwlink/?linkid=2086909");

app.Run();
