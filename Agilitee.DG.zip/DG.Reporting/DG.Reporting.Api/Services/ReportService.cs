

namespace DG.Reporting.Api.Services;

public class ReportService : Report.ReportBase
{
    private readonly IMediator mediator;
    private readonly IMapper mapper;

    public ReportService(IMediator mediator, IMapper mapper)
    {
        this.mediator = mediator;
        this.mapper = mapper;
    }

    public override async Task GetSalesSummary(GetSalesSummaryRequest request, IServerStreamWriter<GetSalesSummaryResponse> responseStream, ServerCallContext context)
    {
        var salesSummary = await mediator.Send(new GetSalesSummaryQuery(request.PAGENUMBER, request.PAGESIZE));
        var salesSummaryDTOs = salesSummary.Select(mapper.Map<SalesSummaryDTO>);
        foreach (var salesSummaryDTO in salesSummaryDTOs)
        {
            //GetSalesSummaryResponse salesSummaryItem = mapper.Map<GetSalesSummaryResponse>(salesSummaryDTO);
            GetSalesSummaryResponse salesSummaryItem = new GetSalesSummaryResponse()
            {
                FiscalPeriod = salesSummaryDTO.FiscalPeriod,
                StoreNumber = salesSummaryDTO.StoreNumber,
                StartDate = salesSummaryDTO.StartDate,
                EndDate = salesSummaryDTO.EndDate,
                Description = salesSummaryDTO.Description,
                TransactionType = salesSummaryDTO.TransactionType,
                Retailvalue = salesSummaryDTO.Retailvalue
            };
            await responseStream.WriteAsync(salesSummaryItem);
        }
    }

    public override async Task GetEventMarkdowns(GetEventMarkdownRequest request, IServerStreamWriter<GetEventMarkdownResponse> responseStream, ServerCallContext context)
    {
        var result = await mediator.Send(new SearchEventMarkdownQuery(request.PAGENUMBER, request.PAGESIZE, request.STORENO, request.FISCALPERIOD, request.TRANSTYPE, request.ENDDATE,request.RETAILVALUE));
        var resultDTOs = result.Select(mapper.Map<EventMarkdownDTO>);
        foreach (var dto in resultDTOs)
        {
            GetEventMarkdownResponse salesSummaryItem = new()
            {
                FiscalPeriod = dto.FiscalPeriod,
                StoreNumber = dto.StoreNumber,
                EndDate = dto.EndDate,
                TransactionType = dto.TransactionType,
                Retailvalue = dto.Retailvalue
            };
            await responseStream.WriteAsync(salesSummaryItem);
        }
    }
    public override async Task GetWarehouseInvoices(GetWarehouseInvoiceRequest request, IServerStreamWriter<GetWarehouseInvoiceResponse> responseStream, ServerCallContext context)
    {
        var result = await mediator.Send(new GetWarehouseInvoiceQuery(request.PAGENUMBER, request.PAGESIZE));
        var resultDTOs = result.Select(mapper.Map<WarehouseInvoiceDTO>);
        foreach (var dto in resultDTOs)
        {
            GetWarehouseInvoiceResponse salesSummaryItem = new()
            {
                FiscalPeriod = dto.FiscalPeriod,
                StoreNumber = dto.StoreNumber,
                TrailerNumber = dto.TrailerNumber,
                InvoiceDate = dto.InvoiceDate,
                InvoiceNumber = dto.InvoiceNumber,
                BatchId = dto.BatchId,
                Retailvalue = dto.Retailvalue
            };
            await responseStream.WriteAsync(salesSummaryItem);
        }
    }

    public override async Task GetDropshipInvoices(GetDropshipInvoiceRequest request, IServerStreamWriter<GetDropshipInvoiceResponse> responseStream, ServerCallContext context)
    {
        var result = await mediator.Send(new SearchDropshipInvoiceQuery(request.PAGENUMBER, request.PAGESIZE, request.STORENO, request.FISCALPERIOD, request.VENDORNAME, request.DATE, request.INVOICENO, request.INVOICETYPE, request.SSCSTATUS));
        var resultDTOs = result.Select(mapper.Map<DropshipInvoiceDTO>);
        foreach (var dto in resultDTOs)
        {
            GetDropshipInvoiceResponse dropshipItem = new()
            {
                StoreNumber = dto.StoreNumber,
                FiscalPeriod = dto.FiscalPeriod,
                VendorName = dto.VendorName,
                InvoiceDate = dto.InvoiceDate,
                InvoiceNumber = dto.InvoiceNumber,
                InvoiceType = dto.InvoiceType,
                SSCStatus = dto.SSCStatus,
                Retailvalue = dto.Retailvalue
            };
            await responseStream.WriteAsync(dropshipItem);
        }
    }

    public override async Task GetSSCAdjustments(GetSSCAdjustmentRequest request, IServerStreamWriter<GetSSCAdjustmentResponse> responseStream, ServerCallContext context)
    {
        var result = await mediator.Send(new GetSSCAdjustmentQuery(request.PAGENUMBER, request.PAGESIZE));
        var resultDTOs = result.Select(mapper.Map<SSCAdjustmentDTO>);
        foreach (var dto in resultDTOs)
        {
            GetSSCAdjustmentResponse salesSummaryItem = new()
            {
                FiscalPeriod = dto.FiscalPeriod,
                StoreNumber = dto.StoreNumber,
                Date = dto.Date,
                Description = dto.Description,
                TransactionType = dto.TransactionType,
                Retailvalue = dto.Retailvalue
            };
            await responseStream.WriteAsync(salesSummaryItem);
        }
    }

    public override async Task GetSBTTransactions(GetsbttransactionRequest request, IServerStreamWriter<GetsbttransactionResponse> responseStream, ServerCallContext context)
    {
        var result = await mediator.Send(new GetSBTTransactionQuery(request.PAGENUMBER, request.PAGESIZE));
        var resultDTOs = result.Select(mapper.Map<SBTTransactionDTO>);
        foreach (var dto in resultDTOs)
        {
            GetsbttransactionResponse salesSummaryItem = new()
            {
                FiscalPeriod = dto.FiscalPeriod,
                StoreNumber = dto.StoreNumber,
                StartDate = dto.StartDate,
                EndDate = dto.EndDate,
                TransactionType = dto.TransactionType,
                Retailvalue = dto.Retailvalue
            };
            await responseStream.WriteAsync(salesSummaryItem);
        }
    }

}
